from PIL import Image as img
import sys
import nxt
from time import sleep
import threading

MAX_SPEED = 127
PAPER = nxt.PORT_A
RAIL = nxt.PORT_B
PEN = nxt.PORT_C
TOUCH = nxt.PORT_1
RGB = nxt.PORT_3
MOVE_PEN = 40
SPEED_PEN = 5
PRINT_SPEED = 40
MIN_MOVE = 20
X_BOUND = 1300
Y_BOUND = 1600
X_POSITIVE = 1
Y_POSITIVE = -1
X_NEGATIVE = -1
Y_NEGATIVE = 1

def initialize(brick, paper, rail, rgb, touch, pen):
	t1 = threading.Thread(target=init_paper, args=(paper, rgb))
	t2 = threading.Thread(target=init_rail, args=(rail, touch))
        try:
                pen.turn(MAX_SPEED/5, 20)
        except Exception as e:
                print e
	#stop to force motor
	pen.weak_turn(0,0)
	pen.reset_position(0)
        t1.start()
        t2.start()
        t1.join()
	t2.join()

def init_paper(p_motor, rgb_sensor):
	# if does not work, set 6 to different of 1
	while(rgb_sensor.get_color() != 6):
                p_motor.turn(MAX_SPEED/2, 5)
        
def init_rail(r_motor, t_sensor):
	i = 0
	while(not t_sensor.get_sample()):
                r_motor.turn(-MAX_SPEED, 15)
                i += 15
				
class print_file(object):
 	# img is an group of coordinates to draw
	def __init__(self):
                # pass
		# get NXT USB information
		self.brick = nxt.locator.find_one_brick()
		# define motors
		self.paper = nxt.Motor(self.brick, PAPER)	
		self.rail = nxt.Motor(self.brick, RAIL)	
		self.pen = nxt.Motor(self.brick, PEN)	
		# define sensors
		self.touch = nxt.sensor.Touch(self.brick, TOUCH)	
		self.rgb = nxt.sensor.Color20(self.brick, RGB)	
		##init_paper(self.paper, self.rgb)
		#init_rail(self.rail, self.touch)
		self.pen_is_down = False
		self.x_pos = 0
		self.y_pos = Y_BOUND
		initialize(self.brick, self.paper, self.rail, self.rgb, self.touch, self.pen)
        def end_print(self):
                self.set_position(X_BOUND,Y_BOUND)
		
	def can_move(self, x=0, y=0):
		if ((self.x_pos + x < X_BOUND) and (self.y_pos + Y_BOUND)):
			return True
		else:
			return False

	def set_position(self, x, y):
		to_move_x = x - self.x_pos
		to_move_y = y - self.y_pos
		
		# move to negative way
		if to_move_x < 0:
			self.move(X_NEGATIVE, abs(to_move_x), self.rail)	
		#move to positive way
		else:
			self.move(X_POSITIVE, abs(to_move_x), self.rail)	
			
		# move to negative way
		if to_move_y < 0:
			self.move(Y_NEGATIVE, abs(to_move_y), self.paper)	
		#move to positive way
		else:
			self.move(Y_POSITIVE, abs(to_move_y), self.paper)	

	def move(self, direction, size, motor):
		motor.reset_position(0)
		if motor == self.paper:
			self.y_pos -= size*direction
		elif motor == self.rail:
			self.x_pos -= size*-direction
		
		while size > 30:
			#TODO verificar se pode mexer
			motor.turn(PRINT_SPEED*direction, size)
			walked = abs(motor.get_tacho().rotation_count)
			size -= walked
			if size < MIN_MOVE:
				size = 0

	def f_move(self, direction, size, motor):
		motor.reset_position(0)
		while size > 30:
			#TODO verificar se pode mexer
			motor.turn(MAX_SPEED*direction, size)
			walked = abs(motor.get_tacho().rotation_count)
			size -= walked
			if size < MIN_MOVE:
				size = 0

	def down_pen(self):
		if not self.pen_is_down:
			self.pen.turn(-SPEED_PEN, MOVE_PEN)
			self.pen_is_down = True
		
	def up_pen(self):
		if self.pen_is_down:
			self.pen.turn(SPEED_PEN, MOVE_PEN)
			self.pen.weak_turn(0,0)
			self.pen_is_down = False

        def draw_raster(self,filename):
                i = img.open(filename)
                size = i.size
                oldcolor = 'b' # branco
                for x in range(1, size[0],40):
                        for y in range(1, size[1], 40):
                                px = i.getpixel((x,y))
                                #print px
                                #era branco, ficou preto
                                if px == 0 and oldcolor == 'b':
                                        print(x,y)
                                        self.set_position(x,y)
                                        self.down_pen()
                                        # self.up_pen()
                                        oldcolor = 'p'
                                #era preto, ficou branco
                                elif px != 0 and oldcolor == 'p':
                                        print (x,y)
                                        self.set_position(x,y)
                                        # self.down_pen()
                                        self.up_pen()
                                        oldcolor = 'b'

print sys.argv[1]                               
print_file().draw_raster(sys.argv[1])
print_file().end_print()
#print_file.draw_square()
