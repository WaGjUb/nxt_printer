#!/bin/bash

if [ $# != 1 ]
then
    echo "Usage: $0 <imagem>"
    exit 1
fi

file=$(mktemp)

convert -resize 60x60\! $1 $file

python main.py $file
